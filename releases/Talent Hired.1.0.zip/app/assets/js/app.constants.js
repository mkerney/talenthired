angular.module('app.constants', [])

.constant('APP', {version:'1.0'})

;